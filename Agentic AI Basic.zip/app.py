"""
app.py  —  AI Math Assistant (Streamlit UI)
============================================
Streamlit frontend for the LangChain tool-calling math agent.

Run:
  streamlit run app.py
"""

import os
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="AI Math Assistant",
    page_icon="🧮",
    layout="wide",
)

# ── CSS ─────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;500&display=swap');

  html, body, [class*="css"]  { font-family: 'DM Sans', sans-serif; }
  h1, h2, h3 { font-family: 'Syne', sans-serif !important; }

  .tool-card {
    background: white; border-radius: 12px; padding: 16px 20px;
    border-left: 4px solid #0070AD;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06); margin-bottom: 10px;
  }
  .tool-card.add      { border-color: #2DC653; }
  .tool-card.subtract { border-color: #E63946; }
  .tool-card.multiply { border-color: #FF9F1C; }
  .tool-card.divide   { border-color: #845EC2; }

  .step-box {
    background: #F8F9FA; border-radius: 8px; padding: 14px 18px;
    font-family: 'DM Mono', monospace; font-size: 13px;
    border: 1px solid #E0E0E0; margin-bottom: 8px;
  }
  .answer-box {
    background: linear-gradient(135deg, #0070AD, #004E7C);
    color: white; border-radius: 12px; padding: 20px 24px;
    font-size: 18px; font-weight: 600; margin-top: 16px;
    font-family: 'Syne', sans-serif;
  }
  .tag {
    font-size: 10px; font-weight: 700; letter-spacing: .12em;
    text-transform: uppercase; margin-bottom: 4px;
  }
  .sidebar-box {
    background: #EBF5FB; border-radius: 8px;
    padding: 14px; font-size: 13px; color: #2c5f7a;
  }
</style>
""", unsafe_allow_html=True)

# ── Sidebar ─────────────────────────────────────────────
with st.sidebar:
    st.image("https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Capgemini_201x_logo.svg/320px-Capgemini_201x_logo.svg.png", width=150)
    st.markdown("## ⚙️ Configuration")

    api_key  = st.text_input("Capgemini API Key", type="password", placeholder="Paste your key")
    base_url = st.text_input("Generative Engine URL", placeholder="https://your-engine/v1")

    if api_key:  os.environ["CAPGEMINI_API_KEY"]  = api_key
    if base_url: os.environ["CAPGEMINI_BASE_URL"] = base_url

    st.divider()
    st.markdown("### 🛠️ Available Tools")
    for emoji, name, color, desc in [
        ("➕", "add",      "#2DC653", "Adds two numbers"),
        ("➖", "subtract", "#E63946", "Subtracts b from a"),
        ("✖️", "multiply", "#FF9F1C", "Multiplies two numbers"),
        ("➗", "divide",   "#845EC2", "Divides a by b (safe ÷0 check)"),
    ]:
        st.markdown(f"""<div class="tool-card {name}">
<span style="font-size:18px">{emoji}</span>
<b style="color:{color}"> {name}(a, b)</b><br>
<span style="font-size:12px;color:#666">{desc}</span>
</div>""", unsafe_allow_html=True)

    st.divider()
    st.markdown("### 🔄 How Tool Calling Works")
    st.markdown("""<div class="sidebar-box">
1️⃣ You ask a math question<br>
2️⃣ LLM reads query + tool descriptions<br>
3️⃣ LLM decides: <b>which tool + what args</b><br>
4️⃣ Tool runs real Python math<br>
5️⃣ LLM formats the answer<br><br>
<b>LLM never does arithmetic itself</b> — that's why it's accurate!
</div>""", unsafe_allow_html=True)

    st.caption("LangChain Tool Calling · GPT-4o · Capgemini")

# ── Header ───────────────────────────────────────────────
st.markdown("<h1 style='font-size:2rem;margin-bottom:4px;'>🧮 AI Math Assistant</h1>", unsafe_allow_html=True)
st.markdown("<p style='color:#666;font-size:15px;margin-bottom:8px;'>LangChain Tool Calling · No hallucinations · Real Python math</p>", unsafe_allow_html=True)

# ── Why tool calling? callout ────────────────────────────
st.info("💡 **Why tool calling?** LLMs sometimes hallucinate math answers. Here the LLM only decides *which tool to call* — the actual arithmetic is always done by Python. Guaranteed accuracy.")

# ── Sample questions ─────────────────────────────────────
SAMPLES = [
    "What is 128 + 374?",
    "Subtract 49 from 200",
    "Multiply 13 by 17",
    "Divide 144 by 12",
    "What is 1 + 1?",
    "Divide 10 by 0",
    "What is 3.14 times 2?",
    "What is 1000 minus 337?",
]

st.markdown("#### 💬 Ask a Math Question")
col_a, col_b = st.columns([3, 1])
with col_a:
    choice   = st.selectbox("Sample questions:", ["— write your own —"] + SAMPLES)
    question = st.text_input("Your question:", value="" if choice == "— write your own —" else choice,
                              placeholder="e.g. What is 25 multiplied by 4?")
with col_b:
    st.markdown("<br>", unsafe_allow_html=True)
    run_btn = st.button("▶ Solve", use_container_width=True)

# ── Run ──────────────────────────────────────────────────
if run_btn:
    if not question.strip():
        st.warning("Please enter a math question.")
        st.stop()
    if not api_key:
        st.warning("⚠️ Enter your Capgemini API Key in the sidebar.")
        st.stop()

    with st.spinner("🤖 Agent thinking..."):
        try:
            # Import here so env vars are set before LangChain initialises
            from agent import build_agent, run_query

            # Cache the agent in session state so we don't rebuild on every click
            if "agent_executor" not in st.session_state:
                st.session_state.agent_executor = build_agent()

            result = run_query(st.session_state.agent_executor, question)

        except Exception as e:
            st.error(f"Agent error: {e}")
            st.stop()

    st.divider()
    st.markdown("### 🔍 Agent Trace — Step by Step")

    # ── Show intermediate steps (tool calls) ─────────────
    steps = result["steps"]
    if steps:
        for i, (action, observation) in enumerate(steps, 1):
            tool_name = getattr(action, "tool", "unknown")
            tool_args = getattr(action, "tool_input", {})
            icon = {"add": "➕", "subtract": "➖",
                    "multiply": "✖️", "divide": "➗"}.get(tool_name, "🔧")

            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f'<p class="tag" style="color:#0070AD;">Step {i} — LLM Decision</p>', unsafe_allow_html=True)
                st.markdown(f"""<div class="step-box">
🤖 LLM chose tool: <b>{icon} {tool_name}</b><br>
📥 Arguments: <b>a = {tool_args.get('a', '?')},  b = {tool_args.get('b', '?')}</b>
</div>""", unsafe_allow_html=True)
            with col2:
                st.markdown(f'<p class="tag" style="color:#2DC653;">Step {i} — Tool Result</p>', unsafe_allow_html=True)
                st.markdown(f"""<div class="step-box">
⚙️ Python executed: <b>{tool_name}({tool_args.get('a','?')}, {tool_args.get('b','?')})</b><br>
📤 Result: <b>{observation}</b>
</div>""", unsafe_allow_html=True)
    else:
        st.info("No tool was called — the question may not require math.")

    # ── Final answer ─────────────────────────────────────
    st.markdown(f"""
<div class="answer-box">
  <div style="font-size:11px;opacity:.7;letter-spacing:.1em;margin-bottom:6px;">FINAL ANSWER</div>
  {result['answer']}
</div>""", unsafe_allow_html=True)

    # ── Stats ─────────────────────────────────────────────
    st.divider()
    c1, c2, c3 = st.columns(3)
    c1.metric("🛠️ Tools Called",   len(steps))
    c2.metric("🧠 Model",          "GPT-4o")
    c3.metric("✅ Hallucination",  "Impossible — Python did the math")

# ── History table ─────────────────────────────────────────
if "history" not in st.session_state:
    st.session_state.history = []

if run_btn and "result" in dir() and result:
    st.session_state.history.append({
        "Question": question,
        "Answer":   result["answer"],
        "Tools Used": len(result["steps"]),
    })

if st.session_state.history:
    st.divider()
    st.markdown("### 📋 Session History")
    st.dataframe(st.session_state.history, use_container_width=True)
    if st.button("🗑️ Clear History"):
        st.session_state.history = []
        st.rerun()
