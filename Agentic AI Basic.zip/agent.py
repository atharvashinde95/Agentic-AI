"""
agent.py
---------
Builds the LangChain tool-calling agent.

Flow:
  User query
      ↓
  LLM reads query + tool descriptions
      ↓
  LLM decides: which tool? with what arguments?
      ↓
  Tool executes (real Python math — no hallucination)
      ↓
  LLM formats the final answer

This is the core of tool calling — the LLM never does the math itself.
It only decides WHICH tool to call and with WHAT numbers.
"""

from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate
from tools.math_tools import MATH_TOOLS
from utils.llm_client import get_llm


SYSTEM_PROMPT = """You are a precise AI Math Assistant powered by Capgemini's Generative Engine.

You have access to 4 math tools: add, subtract, multiply, divide.

IMPORTANT RULES:
- Always use a tool to perform calculations. Never compute in your head.
- For multi-step problems, call tools one step at a time.
- After getting the tool result, explain it clearly to the user.
- If the input is not a math question, politely say so.
"""


def build_agent() -> AgentExecutor:
    """
    Create and return a LangChain tool-calling AgentExecutor.
    Call this once and reuse across queries.
    """
    llm    = get_llm()
    prompt = ChatPromptTemplate.from_messages([
        ("system",    SYSTEM_PROMPT),
        ("human",     "{input}"),
        ("placeholder", "{agent_scratchpad}"),   # LangChain uses this for tool call history
    ])

    # Bind tools to the LLM so it knows what's available
    agent = create_tool_calling_agent(
        llm=llm,
        tools=MATH_TOOLS,
        prompt=prompt,
    )

    return AgentExecutor(
        agent=agent,
        tools=MATH_TOOLS,
        verbose=True,           # prints tool calls to terminal — great for demos!
        handle_parsing_errors=True,
        max_iterations=6,       # safety limit
    )


def run_query(executor: AgentExecutor, question: str) -> dict:
    """
    Run one math question through the agent.
    Returns a dict with the answer and intermediate steps.
    """
    response = executor.invoke({"input": question})
    return {
        "question":   question,
        "answer":     response.get("output", "No answer returned."),
        "steps":      response.get("intermediate_steps", []),
    }
