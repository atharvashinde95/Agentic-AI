"""
utils/llm_client.py
--------------------
Configures the LangChain-compatible LLM pointing at
Capgemini's Generative Engine (OpenAI-compatible endpoint).
"""

import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()


def get_llm() -> ChatOpenAI:
    """Return a LangChain ChatOpenAI client configured for Capgemini."""
    return ChatOpenAI(
        model=os.getenv("MODEL_NAME", "gpt-4o"),
        api_key=os.getenv("CAPGEMINI_API_KEY", "your-key-here"),
        base_url=os.getenv("CAPGEMINI_BASE_URL", "https://api.openai.com/v1"),
        temperature=0,          # 0 = deterministic, important for math
    )
