"""
tools/math_tools.py
--------------------
Four math tools registered with LangChain's @tool decorator.

The LLM reads the docstring to understand WHEN and HOW to call each tool.
Good docstrings = the LLM picks the right tool every time.
"""

from langchain_core.tools import tool


@tool
def add(a: float, b: float) -> str:
    """
    Add two numbers together.
    Use this tool when the user asks for addition, sum, total, or plus.
    Example: 'What is 15 + 27?' or 'Add 3.5 and 2.1'
    """
    try:
        result = a + b
        return f"{a} + {b} = {result}"
    except Exception as e:
        return f"Error in addition: {str(e)}"


@tool
def subtract(a: float, b: float) -> str:
    """
    Subtract b from a (a - b).
    Use this tool when the user asks for subtraction, difference, minus, or take away.
    Example: 'What is 100 - 45?' or 'Subtract 7 from 20'
    """
    try:
        result = a - b
        return f"{a} - {b} = {result}"
    except Exception as e:
        return f"Error in subtraction: {str(e)}"


@tool
def multiply(a: float, b: float) -> str:
    """
    Multiply two numbers together.
    Use this tool when the user asks for multiplication, product, times, or by.
    Example: 'What is 6 times 8?' or 'Multiply 3.14 by 2'
    """
    try:
        result = a * b
        return f"{a} × {b} = {result}"
    except Exception as e:
        return f"Error in multiplication: {str(e)}"


@tool
def divide(a: float, b: float) -> str:
    """
    Divide a by b (a ÷ b).
    Use this tool when the user asks for division, quotient, divided by, or split.
    Example: 'What is 100 divided by 4?' or 'Divide 9 by 3'
    Always checks for division by zero before calculating.
    """
    try:
        if b == 0:
            return "Error: Cannot divide by zero."
        result = a / b
        return f"{a} ÷ {b} = {result}"
    except Exception as e:
        return f"Error in division: {str(e)}"


# Export all tools as a list — imported by the agent
MATH_TOOLS = [add, subtract, multiply, divide]
