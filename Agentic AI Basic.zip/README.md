# 🧮 AI Math Assistant — LangChain Tool Calling

LangChain tool-calling agent with GPT-4o via Capgemini Generative Engine.

## File Structure
```
math_assistant/
├── app.py                  ← Streamlit UI
├── agent.py                ← LangChain AgentExecutor
├── .env                    ← API credentials (do not commit)
├── requirements.txt
├── tools/
│   └── math_tools.py       ← @tool decorated functions (add, subtract, multiply, divide)
└── utils/
    └── llm_client.py       ← Capgemini LLM config
```

## Run
```bash
pip install -r requirements.txt
# Fill in .env with your key and URL
streamlit run app.py
```

## How Tool Calling Works
```
User: "What is 128 + 374?"
  → LLM reads query + tool descriptions
  → LLM decides: call add(a=128, b=374)
  → Python runs: 128 + 374 = 502
  → LLM: "128 + 374 = 502"
```
LLM never does arithmetic — Python does. Zero hallucination.
